﻿using System;

class Program
{
    static void Main()
    {
        int n = 4;
        int[,] graph = {{0, 10, 15, 20},
                        {10, 0, 35, 25},
                        {15, 35, 0, 30},
                        {20, 25, 30, 0}};

        int[] minPath = TSPIterative(n, graph);

        Console.WriteLine("En kısa yol:");
        foreach (int city in minPath)
        {
            Console.Write(city + " ");
        }
        Console.WriteLine();
        Console.WriteLine("Maliyet: " + CalculateCost(minPath, graph));
    }

    static int[] TSPIterative(int n, int[,] graph)
    {
        int[] minPath = new int[n];
        int[] cities = new int[n];
        for (int i = 0; i < n; i++)
        {
            cities[i] = i;
        }

        int minCost = int.MaxValue;

        do
        {
            int currentCost = 0;
            for (int i = 0; i < n - 1; i++)
            {
                currentCost += graph[cities[i], cities[i + 1]];
            }
            currentCost += graph[cities[n - 1], cities[0]];

            if (currentCost < minCost)
            {
                minCost = currentCost;
                Array.Copy(cities, minPath, n);
            }

        } while (NextPermutation(cities));

        return minPath;
    }

    static bool NextPermutation(int[] array)
    {
        int i = array.Length - 2;
        while (i >= 0 && array[i] >= array[i + 1])
        {
            i--;
        }
        if (i < 0)
        {
            return false;
        }

        int j = array.Length - 1;
        while (array[j] <= array[i])
        {
            j--;
        }

        Swap(array, i, j);

        Array.Reverse(array, i + 1, array.Length - i - 1);

        return true;
    }

    static void Swap(int[] array, int i, int j)
    {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    static int CalculateCost(int[] path, int[,] graph)
    {
        int cost = 0;
        for (int i = 0; i < path.Length - 1; i++)
        {
            cost += graph[path[i], path[i + 1]];
        }
        cost += graph[path[path.Length - 1], path[0]];
        return cost;
    }
}
