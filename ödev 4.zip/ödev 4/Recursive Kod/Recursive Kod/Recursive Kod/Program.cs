﻿using System;

class Program
{
    static void Main()
    {
        int n = 4;
        int[,] graph = {{0, 10, 15, 20},
                        {10, 0, 35, 25},
                        {15, 35, 0, 30},
                        {20, 25, 30, 0}};

        int[] minPath = TSPRecursive(n, graph);

        Console.WriteLine("En kısa yol:");
        foreach (int city in minPath)
        {
            Console.Write(city + " ");
        }
        Console.WriteLine();
        Console.WriteLine("Maliyet: " + CalculateCost(minPath, graph));
    }

    static int[] TSPRecursive(int n, int[,] graph)
    {
        int[] minPath = new int[n];
        int[] path = new int[n];
        bool[] visited = new bool[n];
        int minCost = int.MaxValue;

        path[0] = 0;
        visited[0] = true;
        TSPRecursiveHelper(n, graph, path, visited, 1, 0, ref minPath, ref minCost);

        return minPath;
    }

    static void TSPRecursiveHelper(int n, int[,] graph, int[] path, bool[] visited, int currentCity, int currentCost, ref int[] minPath, ref int minCost)
    {
        if (currentCity == n)
        {
            currentCost += graph[path[currentCity - 1], path[0]];
            if (currentCost < minCost)
            {
                minCost = currentCost;
                Array.Copy(path, minPath, n);
            }
            return;
        }

        for (int i = 0; i < n; i++)
        {
            if (!visited[i])
            {
                path[currentCity] = i;
                visited[i] = true;
                TSPRecursiveHelper(n, graph, path, visited, currentCity + 1, currentCost + graph[path[currentCity - 1], i], ref minPath, ref minCost);
                visited[i] = false;
            }
        }
    }

    static int CalculateCost(int[] path, int[,] graph)
    {
        int cost = 0;
        for (int i = 0; i < path.Length - 1; i++)
        {
            cost += graph[path[i], path[i + 1]];
        }
        cost += graph[path[path.Length - 1], path[0]];
        return cost;
    }
}
