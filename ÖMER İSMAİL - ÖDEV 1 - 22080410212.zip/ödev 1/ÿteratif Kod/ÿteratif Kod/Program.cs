﻿using System;

class Program
{
    static void Main()
    {
        int[] dizi = { 5, 8, 3, 2, 9, 10, 6 };

        int enBuyukSayi = EnBuyukSayiIteratif(dizi);

        Console.WriteLine("En büyük sayı: " + enBuyukSayi);
    }

    static int EnBuyukSayiIteratif(int[] dizi)
    {
        int enBuyuk = dizi[0];

        for (int i = 1; i < dizi.Length; i++)
        {
            if (dizi[i] > enBuyuk)
            {
                enBuyuk = dizi[i];
            }
        }

        return enBuyuk;
    }
}
