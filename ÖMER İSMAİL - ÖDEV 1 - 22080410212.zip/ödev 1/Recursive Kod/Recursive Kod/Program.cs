﻿using System;

class Program
{
    static void Main()
    {
        int[] dizi = { 5, 8, 3, 2, 9, 10, 6 };

        int enBuyukSayi = EnBuyukSayiRecursive(dizi, 0, dizi.Length - 1);

        Console.WriteLine("En büyük sayı: " + enBuyukSayi);
    }

    static int EnBuyukSayiRecursive(int[] dizi, int baslangicIndex, int bitisIndex)
    {
        if (baslangicIndex == bitisIndex)
        {
            return dizi[baslangicIndex];
        }

        int ortaIndex = (baslangicIndex + bitisIndex) / 2;

        int solEnBuyuk = EnBuyukSayiRecursive(dizi, baslangicIndex, ortaIndex);
        int sagEnBuyuk = EnBuyukSayiRecursive(dizi, ortaIndex + 1, bitisIndex);

        return Math.Max(solEnBuyuk, sagEnBuyuk);
    }
}
