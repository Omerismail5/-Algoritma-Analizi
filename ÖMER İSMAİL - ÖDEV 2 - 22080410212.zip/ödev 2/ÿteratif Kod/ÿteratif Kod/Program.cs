﻿using System;

class Program
{
    static void Main()
    {
        int onluSayi = 42;
        string ikiliSayi = OnluToIkiliIteratif(onluSayi);

        Console.WriteLine("Onlu sayı: " + onluSayi);
        Console.WriteLine("İkili sayı: " + ikiliSayi);
    }

    static string OnluToIkiliIteratif(int onluSayi)
    {
        string ikiliSayi = "";

        while (onluSayi > 0)
        {
            int kalan = onluSayi % 2;
            ikiliSayi = kalan + ikiliSayi;
            onluSayi = onluSayi / 2;
        }

        return ikiliSayi;
    }
}
