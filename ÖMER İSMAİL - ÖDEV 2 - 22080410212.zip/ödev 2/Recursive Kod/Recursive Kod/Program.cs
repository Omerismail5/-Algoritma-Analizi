﻿using System;

class Program
{
    static void Main()
    {
        int onluSayi = 42;
        string ikiliSayi = OnluToIkiliRecursive(onluSayi);

        Console.WriteLine("Onlu sayı: " + onluSayi);
        Console.WriteLine("İkili sayı: " + ikiliSayi);
    }

    static string OnluToIkiliRecursive(int onluSayi)
    {
        if (onluSayi == 0)
        {
            return "";
        }

        int kalan = onluSayi % 2;
        return OnluToIkiliRecursive(onluSayi / 2) + kalan;
    }
}
